#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int main() {
    int scores[5];
    int s_count = 0, a_count = 0, b_count = 0, c_count = 0;
    int sum = 0;

    // ��J5��ǥͤ���
    for (int i = 0; i < 5; i++) {
        scanf("%d", &scores[i]);
        sum += scores[i];

        if (scores[i] == 100) {
            s_count++;
        } else if (scores[i] >= 80) {
            a_count++;
        } else if (scores[i] >= 60) {
            b_count++;
        } else {
            c_count++;
        }
    }

    // �L�X�U���ŤH��
    printf("S=%d\n", s_count);
    printf("A=%d\n", a_count);
    printf("B=%d\n", b_count);
    printf("C=%d\n", c_count);

    // �L�X�������� (���)
    printf("AVG=%d\n", sum / 5);

    return 0;
}